package com.irangemkadeh.paymentsms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DepositSmsReceiver extends BroadcastReceiver {
    private static final ExecutorService pool=Executors.newSingleThreadExecutor();
    @Override public void onReceive(Context context, Intent intent) {
        if(!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        SmsMessage[] messages=Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if(messages==null||messages.length==0)return;
        StringBuilder body=new StringBuilder(); long stamp=System.currentTimeMillis(); String sender="";
        for(SmsMessage m:messages){body.append(m.getMessageBody());stamp=m.getTimestampMillis();sender=m.getOriginatingAddress()==null?"":m.getOriginatingAddress();}
        final String msg=body.toString(); final long received=stamp; final String from=sender;
        if(!msg.contains("واریز پول") || !msg.contains("بلو")) return;
        Matcher matcher=Pattern.compile("([0-9][0-9,٬]*)\\s*ریال").matcher(msg);
        if(!matcher.find())return;
        String digits=matcher.group(1).replace(",","").replace("٬",""); long amount;
        try{amount=Long.parseLong(digits);}catch(Exception e){return;}
        if(amount<=0)return;
        SharedPreferences prefs=context.getSharedPreferences("igk",Context.MODE_PRIVATE);
        final String fp=sha256(from+"|"+received+"|"+msg);
        saveLocal(prefs,amount,received,fp,"در انتظار ارسال");
        String site=prefs.getString("site",""); String token=prefs.getString("token","");
        if(!site.startsWith("https://")||token.length()<24){prefs.edit().putString("status","واریزی ذخیره شد؛ اتصال سایت تنظیم نشده").apply();return;}
        final PendingResult pending=goAsync();
        pool.execute(()->{HttpURLConnection c=null;String result;
            try{
                JSONObject data=new JSONObject(); data.put("amount_rial",amount);
                data.put("received_at",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",java.util.Locale.US).format(new java.util.Date(received)));
                data.put("fingerprint",fp);
                c=(HttpURLConnection)new URL(site+"/wp-json/igk/v1/sms").openConnection();
                c.setRequestMethod("POST"); c.setConnectTimeout(12000); c.setReadTimeout(12000); c.setDoOutput(true);
                c.setRequestProperty("Content-Type","application/json; charset=utf-8"); c.setRequestProperty("X-IGK-Token",token);
                try(OutputStream os=c.getOutputStream()){os.write(data.toString().getBytes(StandardCharsets.UTF_8));}
                int code=c.getResponseCode(); result=(code>=200&&code<300)?"ارسال شد؛ پاسخ سایت "+code:"ارسال ناموفق؛ پاسخ "+code;
                prefs.edit().putString("status",result).apply();
            }catch(Exception e){result="خطا در اتصال؛ ارسال مجدد لازم است";prefs.edit().putString("status",result).apply();}
            finally{if(c!=null)c.disconnect();updateLocalResult(prefs,fp,result);pending.finish();}
        });
    }
    private static synchronized void saveLocal(SharedPreferences p,long amount,long time,String fp,String result){
        try{JSONArray a=new JSONArray(p.getString("transactions","[]"));JSONObject o=new JSONObject();
            o.put("amount",amount);o.put("date",new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm:ss",java.util.Locale.US).format(new java.util.Date(time)));
            o.put("fingerprint",fp);o.put("result",result);a.put(o);
            while(a.length()>300){JSONArray n=new JSONArray();for(int i=1;i<a.length();i++)n.put(a.get(i));a=n;}
            p.edit().putString("transactions",a.toString()).apply();
        }catch(Exception ignored){}
    }
    private static synchronized void updateLocalResult(SharedPreferences p,String fp,String result){
        try{JSONArray a=new JSONArray(p.getString("transactions","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(fp.equals(o.optString("fingerprint"))){o.put("result",result);break;}}
            p.edit().putString("transactions",a.toString()).apply();
        }catch(Exception ignored){}
    }
    private static String sha256(String s){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder x=new StringBuilder();for(byte v:b)x.append(String.format(java.util.Locale.US,"%02x",v));return x.toString();}catch(Exception e){return Long.toHexString(System.nanoTime());}}
}

package com.irangemkadeh.paymentsms;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    EditText site, token;
    TextView connection, count, list;
    SharedPreferences prefs;
    LinearLayout root;
    int blue=Color.rgb(28,100,190);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("igk",MODE_PRIVATE);
        buildUi();
        renderTransactions();
    }
    TextView text(String value,int size,int color){
        TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,8,0,8); return t;
    }
    void buildUi(){
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,28,24,24); root.setBackgroundColor(Color.rgb(246,248,251));
        TextView title=text("همراه پرداخت ایران جم کده",23,Color.rgb(25,45,75)); title.setGravity(Gravity.CENTER); root.addView(title);
        connection=text("وضعیت اتصال: "+prefs.getString("status","تنظیم نشده"),14,blue); root.addView(connection);
        root.addView(text("اتصال به سایت",18,Color.BLACK));
        site=new EditText(this); site.setSingleLine(true); site.setHint("https://example.com"); site.setInputType(InputType.TYPE_TEXT_VARIATION_URI); site.setText(prefs.getString("site","")); root.addView(site);
        token=new EditText(this); token.setSingleLine(true); token.setHint("کلید اتصال افزونه"); token.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); token.setText(prefs.getString("token","")); root.addView(token);
        Button save=new Button(this); save.setText("ذخیره تنظیمات و فعال‌سازی پیامک"); root.addView(save);
        save.setOnClickListener(v->{
            String u=site.getText().toString().trim(), k=token.getText().toString().trim();
            if(!u.startsWith("https://")||k.length()<24){Toast.makeText(this,"آدرس HTTPS و کلید حداقل ۲۴ کاراکتری وارد کنید.",Toast.LENGTH_LONG).show();return;}
            prefs.edit().putString("site",u.replaceAll("/+$","")).putString("token",k).putString("status","تنظیمات ذخیره شد").apply();
            if(checkSelfPermission(Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS},77);
            else {Toast.makeText(this,"تنظیمات ذخیره شد.",Toast.LENGTH_SHORT).show(); refreshStatus();}
        });
        root.addView(text("تراکنش‌های شناسایی‌شده",19,Color.BLACK));
        count=text("",14,blue); root.addView(count);
        Button refresh=new Button(this); refresh.setText("به‌روزرسانی فهرست"); root.addView(refresh);
        refresh.setOnClickListener(v->renderTransactions());
        list=text("هنوز تراکنشی ثبت نشده است.",14,Color.DKGRAY); root.addView(list);
        TextView privacy=text("این برنامه فقط پیامک‌های واریز شناسایی‌شده را پردازش می‌کند. پیامک برداشت نادیده گرفته می‌شود. متن کامل پیامک ذخیره یا ارسال نمی‌شود.",12,Color.GRAY); root.addView(privacy);
        scroll.addView(root); setContentView(scroll);
    }
    void refreshStatus(){connection.setText("وضعیت اتصال: "+prefs.getString("status","تنظیم نشده"));}
    void renderTransactions(){
        refreshStatus();
        try {
            JSONArray arr=new JSONArray(prefs.getString("transactions","[]"));
            count.setText("تعداد ثبت‌شده: "+arr.length());
            if(arr.length()==0){list.setText("هنوز تراکنشی ثبت نشده است.");return;}
            StringBuilder out=new StringBuilder();
            for(int i=arr.length()-1;i>=0;i--){
                JSONObject o=arr.getJSONObject(i);
                out.append("مبلغ: ").append(String.format("%,d",o.optLong("amount"))).append(" ریال\n");
                out.append("زمان: ").append(o.optString("date","-")).append("\n");
                out.append("وضعیت ارسال: ").append(o.optString("result","در انتظار ارسال")).append("\n");
                out.append("------------------------------\n");
            }
            list.setText(out.toString());
        } catch(Exception e){list.setText("خواندن فهرست تراکنش‌ها ممکن نشد.");}
    }
    @Override public void onResume(){super.onResume(); if(prefs!=null) renderTransactions();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        super.onRequestPermissionsResult(r,p,g);
        if(r==77&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putString("status","دسترسی پیامک فعال است").apply();
            Toast.makeText(this,"دسترسی پیامک فعال شد.",Toast.LENGTH_LONG).show();
        } else if(r==77) Toast.makeText(this,"بدون اجازه پیامک، تشخیص واریز ممکن نیست.",Toast.LENGTH_LONG).show();
        renderTransactions();
    }
}
